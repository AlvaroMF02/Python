from .basic_math import suma, resta, multiplicacion, division
from .advanced_math import potencia, raiz_cuadrada, factorial
