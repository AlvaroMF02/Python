import math

def potencia(base, exponente):
    return base ** exponente

def raiz_cuadrada(numero):
    return math.sqrt(numero)

def factorial(numero):
    return math.factorial(numero)
